package com.cg.billing.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.beans.PostpaidAccount;


public class PostPaidAcocuntDaoImpl implements PostPaidAccountDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public PostpaidAccount save(PostpaidAccount postpaidAccount) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.persist(postpaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return postpaidAccount;	
	}

	@Override
	public boolean update(PostpaidAccount postpaidAccount) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.merge(postpaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
				return false;
	}

	@Override
	public PostpaidAccount findOne(long mobileNo) {
		return entityManagerFactory.createEntityManager().find(PostpaidAccount.class, mobileNo);


	}

	@Override
	public List<PostpaidAccount> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(PostpaidAccount postpaidAccount) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.remove(postpaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}

}
