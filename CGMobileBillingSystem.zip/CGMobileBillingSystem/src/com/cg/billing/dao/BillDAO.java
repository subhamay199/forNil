package com.cg.billing.dao;
import java.util.HashMap;
import com.cg.billing.beans.Bill;
public interface BillDAO {
	Bill save(Bill bills);
	boolean update(Bill bills);
	Bill findOne(int i);
	HashMap<Integer,Bill> findAll();
}
