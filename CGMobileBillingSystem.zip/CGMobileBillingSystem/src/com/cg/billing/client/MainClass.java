package com.cg.billing.client;

import java.util.Scanner;

import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServiceImpl;
import com.cg.billing.services.BillingServices;

public class MainClass {

	public static void main(String[] args) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException  {		
		BillingServices services = new BillingServiceImpl();
//		BankingServicesImpl account = new BankingServicesImpl();
		//long accountNoTo,accountNoFrom,transferAmount;
		//BillingServices services=new BillingServiceImpl();
		while(true) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. create Postpaid Account");
		System.out.println("2. get Customer details");
		System.out.println("3. get every Customer details");
		System.out.println("4.Change Plan ");
	
		System.out.println("6.Accept Customer Details");
		System.out.println("7.Close PostPaid Account");
		System.out.println("8.Remove Customer Details");
		System.out.println("9.Get Customer All Plan Details");
		System.out.println("10.Get All PostPaid Account Details");
		System.out.println("11.For Exit");
		int n = sc.nextInt();
		switch(n) {
		case 1:	System.out.println("Enter The Customer Id");
						int customerID=sc.nextInt();
//						System.out.println("Enter The Mobile No");
//						long mobileNo=sc.nextLong();
						System.out.println("Enter The Plan Id");
						int planId=sc.nextInt();
						services.openPostpaidMobileAccount(customerID, planId);break;
		case 2:	System.out.println("Enter The Customer Id");
						int customerID6=sc.nextInt();
						services.getCustomerDetails(customerID6);break;
		case 3: 	System.out.println(services.getAllCustomerDetails());break;
		case 6:		System.out.println("Enter The First Name");
							String firstName=sc.next();
							System.out.println("Enter The Last Name");
							String lastName=sc.next();
							System.out.println("Enter The EmailId");
							String emailID=sc.next();
							System.out.println("Enter The Date Of Birth");
							String dateOfBirth=sc.next();
							System.out.println("Enter The billingAddressCity");
							String billingAddressCity=sc.next();
							System.out.println("Enter The billing AddressState");
							String billingAddressState=sc.next();
							System.out.println("Enter The billingAddressPinCode");
							int billingAddressPinCode=sc.nextInt();
							System.out.println("Enter The HomeAddressCity");
							String homeAddressCity=sc.next();
							System.out.println("Enter The HomeAddressState");
							String homeAddressState=sc.next();
							System.out.println("Enter The HomeAddressPinCode");
							int homeAddressPinCode=sc.nextInt();
							try{services.acceptCustomerDetails(firstName, lastName, emailID, dateOfBirth, billingAddressCity, billingAddressState, billingAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);}
							catch(Exception e) {System.out.println("Null;");}
		case 7:  System.out.println("Enter The Customer Id");
						int customerID3=sc.nextInt();
						System.out.println("Enter The Mobile No");
						long mobileNo3=sc.nextLong();
						services.closeCustomerPostPaidAccount(customerID3, mobileNo3);break;
		case 8: System.out.println("Enter The Customer Id");
						int customerID5=sc.nextInt();		
						services.removeCustomerDetails(customerID5);break;
		case 9:	System.out.println(services.getPlanAllDetails());break;
		case 10:{System.out.println("Enter The Customer Id");
						int customerID2=sc.nextInt();
						System.out.println(services.getCustomerAllPostpaidAccountsDetails(customerID2));}break;
		case 11: System.exit(0);break;
		default:System.out.println("enter correct choice");break;
		}
	}
	}
}

