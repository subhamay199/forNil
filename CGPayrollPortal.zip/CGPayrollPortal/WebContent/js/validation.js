function validateLoginForm() {
	if(loginForm.associateId.value==""){
		alert("Enter AssociateId");
		return false;
		}
	else if(loginForm.password.value==""){
		alert("Enter Password");
		return false;
	}
}
function validateRegistrationForm() {
	if(RegistrationForm.firstName.value==""){
		alert("Enter First Name");
		return false;
		}
	else if(RegistrationForm.lastName.value==""){
		alert("Enter last Name");
		return false;
	}
	else if(RegistrationForm.department.value==""){
		alert("Enter Department");
		return false;
	}
	else if(RegistrationForm.emailId.value==""){
		alert("Enter EmailId");
		return false;
	}
	else if(RegistrationForm.designation.value==""){
		alert("Enter Designation");
		return false;
	}
	else if(RegistrationForm.yearlyInvestmentUnder8oC.value==""){
		alert("Enter yearlyInvestmentUnder8oC");
		return false;
	}
	else if(RegistrationForm.pancard.value==""){
		alert("Enter pancard");
		return false;
	}
	else if(RegistrationForm.basicSalary.value==""){
		alert("Enter basicSalary");
		return false;
	}
	else if(RegistrationForm.bankName.value==""){
		alert("Enter bankName");
		return false;
	}
	else if(RegistrationForm.ifscCode.value==""){
		alert("Enter ifscCode");
		return false;
	}
	else if(RegistrationForm.accountNo.value==""){
		alert("Enter accountNo");
		return false;
	}
}
function validatePassword(){
	if(changePasswordFrm.password.value.length>=6){
		if((changePasswordFrm.password.value.search(/[0-9]/)!=-1) && (changePasswordFrm.password.value.search(/[A-Z]/)!=-1) &&(changePasswordFrm.password.value.search(/[!@#$%^&*()]/)!=-1)){
			return true;
		}
		else{
			alert("Password must contain atleast 1 no 1uppercase letter 1 lowercsae letter and 1 special character ");
			return false;
		}
	}
	else
		alert("Minimum of 6 characters");
	return false;
}
//function checkSame(){
//	if(changePasswordFrm.password.value!=changePasswordFrm.confirmPassword.value){
////		alert("Wrong");
//		return false;
//	}
