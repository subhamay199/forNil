package com.cg.banking.servlets;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet("/accountDetails")
public class AccountDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	BankingServices bankingServices;

	@Override
	public void init() throws ServletException {
		bankingServices=new BankingServicesImpl();
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
		try {
			Account account=bankingServices.getAccountDetails(accountNumber);
			request.setAttribute("account", account);
			request.getRequestDispatcher("getDetailsSuccess.jsp").forward(request, response);
		} catch (AccountNotFoundException e) {
			request.getRequestDispatcher("getAccountDetails.jsp").forward(request, response);
		} catch (BankingServicesDownException e) {
			request.getRequestDispatcher("getAccountDetails.jsp").forward(request, response);

		}
	}

@Override
	public void destroy() {
		bankingServices=null;
	}

}
