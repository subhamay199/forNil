package com.cg.payroll.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class payrollServicesController {

}
