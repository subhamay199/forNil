package com.cg.payroll.client;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException{
		PayrollServices services=new PayrollServicesImpl();
		double netSalary;
		double grossSalary;
		double empTax;
		Scanner sc=new Scanner(System.in);
		int associateId=services.acceptAssociateDetails("Subhamaya", "Samanta", "subhamaysamnata1997@gmail.com", "IT", "Analyst", "dfggd", 204300, 32540, 1500, 1600, 3793, "sbi", "dgfdf5363");
		System.out.println("Associate Id:- "+associateId);
		int associateId2=services.acceptAssociateDetails("koyel", "ganguly", "koyel98@gmail.com", "IT", "Analyst", "fdghd", 25000, 14000, 1700, 1500, 4321, "axis", "axis821437");
		System.out.println("Associate Id:- "+associateId2);
		while(true) {
		System.out.println("---------------------");
		System.out.println("Enter your choice");
		System.out.println("1. get associate details");
		System.out.println("2. get salary details");
		System.out.println("3. get tax details");
		System.out.println("4. exit");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
//			System.out.println(services.getAllAssociateDetails());
			System.out.println("Enter the employee id you want to search: ");
			int num=sc.nextInt();
			try {
			System.out.println(services.getAssociateDetails(num));
			}
			catch(AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 2:
			System.out.println("Enter associate Id to get salary details : ");
			int sal = sc.nextInt();
			System.out.println("------------");
			boolean a = services.getAssociateDetails(sal) != null;
			try {
				services.getAssociateDetails(sal);
//				if(a=true) {
//					if(sal==associateId) {
						netSalary=services.calculateNetSalary(associateId);
						grossSalary=services.calculateAnnualGrossSalary(associateId);
						System.out.println("Net Salary for EmpId "+ associateId+" is "+netSalary);
						System.out.println("Annual GrossSalary for EmpId "+associateId+" is "+grossSalary);
//					}
//					else if(sal==102) {
//						netSalary=services.calculateNetSalary(associateId2);
//						grossSalary=services.calculateAnnualGrossSalary(associateId2);
//						System.out.println("Net Salary for EmpId "+ associateId2+" is "+netSalary);
//						System.out.println("Annual GrossSalary for EmpId "+associateId2+" is "+grossSalary);
//					}
//				}
			}
				catch(AssociateDetailsNotFoundException e) {
					e.printStackTrace();
			}
			break;
		case 3:
			System.out.println("Enter associate Id to get tax details : ");
			int tax=sc.nextInt();
			boolean a1 = services.getAssociateDetails(tax) != null;
			try {
				services.getAssociateDetails(tax);
//				if(a1=true) {
//					if(tax==101) {
						empTax=services.taxCalculator(associateId);
						System.out.println("Tax of EmpId "+associateId+" is "+empTax);
//						}
//					else if(tax==102) {
//						empTax=services.taxCalculator(associateId2);
//						System.out.println("Tax of EmpId "+associateId2+" is "+empTax);
//					}
//					}
				}
			catch(AssociateDetailsNotFoundException e) {
					e.printStackTrace();
					}
			break;
		case 4: List<Associate> a11=services.getAllAssociateDetails();
		for(Associate associate2: a11) {
			System.out.println(associate2);
		}
		//case 4: System.exit(0);
		default:
			System.out.println("wrong choice");
		}
		}
	}
}