package com.capgemini.xyz.bean;

public class Loan {
	private long loanId;
	private double loanAmount;
	private long custId;
	private String email;
	
	public Loan() {}

	public Loan(long loanId, double loanAmount, long custId, String email) {
		super();
		this.loanId = loanId;
		this.loanAmount = loanAmount;
		this.custId = custId;
		this.email = email;
	}

	public long getLoanId() {
		return loanId;
	}

	public void setLoanId(long loanId) {
		this.loanId = loanId;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public long getCustId() {
		return custId;
	}

	public void setCustId(long custId) {
		this.custId = custId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanAmount=" + loanAmount + ", custId=" + custId + ", email=" + email
				+ "]";
	}
	
	
	
	
}
