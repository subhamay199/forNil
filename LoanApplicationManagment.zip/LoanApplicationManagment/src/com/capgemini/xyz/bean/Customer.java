package com.capgemini.xyz.bean;

public class Customer {
	private long CustId;
	private long custName;
	private String adress;
	private long mobile;
	private String email;
	
	public Customer() {}

	public Customer(long custId, long custName, String adress, long mobile, String email) {
		super();
		CustId = custId;
		this.custName = custName;
		this.adress = adress;
		this.mobile = mobile;
		this.email = email;
	}

	public long getCustId() {
		return CustId;
	}

	public void setCustId(long custId) {
		CustId = custId;
	}

	public long getCustName() {
		return custName;
	}

	public void setCustName(long custName) {
		this.custName = custName;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", custName=" + custName + ", adress=" + adress + ", mobile=" + mobile
				+ ", email=" + email + "]";
	}

}
