package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ILoanService a=new LoanService();
		
		System.out.println("XYZ finance company welcomes you");
		System.out.println("1: Register  Company");
		System.out.println("2: Exit");
		int n=sc.nextInt(); 
			switch(n) { 			
	case 1:
			System.out.println("Register Company ");
			System.out.println("enter the customer name");
			long custName=sc.nextLong();

			System.out.println("enter the address");
			String adress=sc.next();

			String email=sc.next();
			System.out.println("enter email");
			
			
		
		
	}	}
	

}
