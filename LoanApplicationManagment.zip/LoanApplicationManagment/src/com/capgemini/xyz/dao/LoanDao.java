package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDao implements ILoanDao{

	@Override
	public long applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long applyLoan(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

}
