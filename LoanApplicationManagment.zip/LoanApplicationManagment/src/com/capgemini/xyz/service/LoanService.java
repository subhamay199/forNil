package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService{
	ILoanDao b=new LoanDao();
	

	@Override
	public Loan applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer validateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long insertCust(Customer cust) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		// TODO Auto-generated method stub
		return 0;
	}

}
