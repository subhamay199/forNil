package com.capgemini.xyz.util;

public class CollectionUtil {

}
