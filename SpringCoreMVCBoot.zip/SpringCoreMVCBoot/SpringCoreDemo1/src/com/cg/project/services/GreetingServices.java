package com.cg.project.services;

public interface GreetingServices {
public void greetUser(String name);
}
