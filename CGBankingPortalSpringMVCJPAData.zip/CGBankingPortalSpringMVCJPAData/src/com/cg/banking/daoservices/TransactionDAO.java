package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.banking.beans.Transaction;

public interface TransactionDAO extends JpaRepository<Transaction, Integer> {
//	Transaction save(Account account,long accountNo,Transaction transaction);
//	boolean update(long accountNo,Transaction  transaction);
//	Transaction findOne(long accountNo,int transactionId);
//	List<Transaction>findAll(long accountNo);
}
